export const environment = {
  production: true,
  Edukanadmin: 'https://skindevreplica.api.tatamotors',
  TataapiUri: 'https://skindevreplica-tls.api.tatamotors',
    EdukanVss: 'https://skindevreplica.api.tatamotors',
};
