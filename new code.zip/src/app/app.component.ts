import { Component } from '@angular/core';
// import {NgbdDatepickerPopupModule} from './app/datepicker-popup.module';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  
  title = 'tm-admin';
}

// .bootstrapModule(NgbdDatepickerPopupModule)
